function initialUI() {
//alert("init");
$(document).ready(function() { 

    //var myVideo = document.getElementById("video1");    
   // myVideo.play(); 

});
    
}


function showAnimatedCircle() {
//animatedCircle.apend(
    

    var myvar = '<div class="frame">'+
    '<div class="central"></div>'+
    '<div class="ring ring-1">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-2">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-3">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-4">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-5">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-37">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-38">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-39">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-40">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-41">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-42">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-6">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-37">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-38">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-39">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-40">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-41">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-42">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-43">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-44">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-45">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-46">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-47">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-48">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-7">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-37">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-38">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-39">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-40">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-41">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-42">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-43">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-44">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-45">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-46">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-47">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-48">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-49">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-50">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-51">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-52">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-53">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-54">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-8">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-37">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-38">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-39">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-40">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-41">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-42">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-43">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-44">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-45">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-46">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-47">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-48">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-49">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-50">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-51">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-52">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-53">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-54">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-55">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-56">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-57">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-58">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-59">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-60">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-9">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-37">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-38">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-39">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-40">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-41">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-42">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-43">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-44">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-45">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-46">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-47">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-48">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-49">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-50">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-51">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-52">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-53">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-54">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-55">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-56">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-57">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-58">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-59">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-60">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-61">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-62">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-63">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-64">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-65">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-66">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '<div class="ring ring-10">'+
    '<div class="dot dot-1">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-2">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-3">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-4">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-5">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-6">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-7">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-8">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-9">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-10">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-11">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-12">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-13">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-14">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-15">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-16">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-17">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-18">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-19">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-20">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-21">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-22">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-23">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-24">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-25">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-26">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-27">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-28">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-29">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-30">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-31">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-32">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-33">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-34">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-35">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-36">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-37">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-38">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-39">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-40">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-41">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-42">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-43">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-44">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-45">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-46">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-47">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-48">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-49">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-50">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-51">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-52">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-53">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-54">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-55">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-56">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-57">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-58">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-59">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-60">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-61">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-62">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-63">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-64">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-65">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-66">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-67">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-68">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-69">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-70">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-71">'+
    '<div class="fill"></div>'+
    '</div>'+
    '<div class="dot dot-72">'+
    '<div class="fill"></div>'+
    '</div>'+
    '</div>'+
    '</div>';
        
    
	


            var animatedCircle = document.getElementById( "animatedCircle" );

            animatedCircle.append(myvar)

}